<php>
    phpinfo();
</php>